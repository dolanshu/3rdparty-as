rutil/CMakeFiles/rutil.dir/AndroidLogger.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/rutil/AndroidLogger.cxx \
 /usr/include/stdc-predef.h
