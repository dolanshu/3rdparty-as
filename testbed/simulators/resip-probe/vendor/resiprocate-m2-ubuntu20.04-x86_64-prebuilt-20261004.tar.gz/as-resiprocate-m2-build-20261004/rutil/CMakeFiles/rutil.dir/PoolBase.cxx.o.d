rutil/CMakeFiles/rutil.dir/PoolBase.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/rutil/PoolBase.cxx \
 /usr/include/stdc-predef.h \
 /tmp/as-resiprocate-m2-20261004/rutil/PoolBase.hxx \
 /usr/lib/gcc/x86_64-linux-gnu/9/include/stddef.h
