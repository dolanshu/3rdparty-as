
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/as-resiprocate-m2-20261004/rutil/AbstractFifo.cxx" "rutil/CMakeFiles/rutil.dir/AbstractFifo.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/AbstractFifo.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/AndroidLogger.cxx" "rutil/CMakeFiles/rutil.dir/AndroidLogger.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/AndroidLogger.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/BaseException.cxx" "rutil/CMakeFiles/rutil.dir/BaseException.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/BaseException.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Coders.cxx" "rutil/CMakeFiles/rutil.dir/Coders.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Coders.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ConfigParse.cxx" "rutil/CMakeFiles/rutil.dir/ConfigParse.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ConfigParse.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/CountStream.cxx" "rutil/CMakeFiles/rutil.dir/CountStream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/CountStream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Crc32.cxx" "rutil/CMakeFiles/rutil.dir/Crc32.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Crc32.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Data.cxx" "rutil/CMakeFiles/rutil.dir/Data.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Data.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/DataStream.cxx" "rutil/CMakeFiles/rutil.dir/DataStream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/DataStream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/DigestStream.cxx" "rutil/CMakeFiles/rutil.dir/DigestStream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/DigestStream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/DnsUtil.cxx" "rutil/CMakeFiles/rutil.dir/DnsUtil.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/DnsUtil.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/FdPoll.cxx" "rutil/CMakeFiles/rutil.dir/FdPoll.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/FdPoll.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/FileSystem.cxx" "rutil/CMakeFiles/rutil.dir/FileSystem.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/FileSystem.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/GeneralCongestionManager.cxx" "rutil/CMakeFiles/rutil.dir/GeneralCongestionManager.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/GeneralCongestionManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/GenericIPAddress.cxx" "rutil/CMakeFiles/rutil.dir/GenericIPAddress.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/GenericIPAddress.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/HeapInstanceCounter.cxx" "rutil/CMakeFiles/rutil.dir/HeapInstanceCounter.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/HeapInstanceCounter.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/KeyValueStore.cxx" "rutil/CMakeFiles/rutil.dir/KeyValueStore.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/KeyValueStore.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Lock.cxx" "rutil/CMakeFiles/rutil.dir/Lock.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Lock.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Log.cxx" "rutil/CMakeFiles/rutil.dir/Log.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Log.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/MD5Stream.cxx" "rutil/CMakeFiles/rutil.dir/MD5Stream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/MD5Stream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/NetNs.cxx" "rutil/CMakeFiles/rutil.dir/NetNs.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/NetNs.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ParseBuffer.cxx" "rutil/CMakeFiles/rutil.dir/ParseBuffer.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ParseBuffer.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ParseException.cxx" "rutil/CMakeFiles/rutil.dir/ParseException.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ParseException.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Plugin.cxx" "rutil/CMakeFiles/rutil.dir/Plugin.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Plugin.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Poll.cxx" "rutil/CMakeFiles/rutil.dir/Poll.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Poll.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/PoolBase.cxx" "rutil/CMakeFiles/rutil.dir/PoolBase.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/PoolBase.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/RADIUSDigestAuthenticator.cxx" "rutil/CMakeFiles/rutil.dir/RADIUSDigestAuthenticator.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/RADIUSDigestAuthenticator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/RWMutex.cxx" "rutil/CMakeFiles/rutil.dir/RWMutex.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/RWMutex.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Random.cxx" "rutil/CMakeFiles/rutil.dir/Random.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Random.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/SelectInterruptor.cxx" "rutil/CMakeFiles/rutil.dir/SelectInterruptor.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/SelectInterruptor.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ServerProcess.cxx" "rutil/CMakeFiles/rutil.dir/ServerProcess.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ServerProcess.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Sha1.cxx" "rutil/CMakeFiles/rutil.dir/Sha1.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Sha1.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Socket.cxx" "rutil/CMakeFiles/rutil.dir/Socket.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Socket.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Subsystem.cxx" "rutil/CMakeFiles/rutil.dir/Subsystem.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Subsystem.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/SysLogBuf.cxx" "rutil/CMakeFiles/rutil.dir/SysLogBuf.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/SysLogBuf.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/SysLogStream.cxx" "rutil/CMakeFiles/rutil.dir/SysLogStream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/SysLogStream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ThreadIf.cxx" "rutil/CMakeFiles/rutil.dir/ThreadIf.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ThreadIf.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Time.cxx" "rutil/CMakeFiles/rutil.dir/Time.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Time.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/Timer.cxx" "rutil/CMakeFiles/rutil.dir/Timer.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/Timer.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/TransportType.cxx" "rutil/CMakeFiles/rutil.dir/TransportType.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/TransportType.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/XMLCursor.cxx" "rutil/CMakeFiles/rutil.dir/XMLCursor.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/XMLCursor.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/AresDns.cxx" "rutil/CMakeFiles/rutil.dir/dns/AresDns.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/AresDns.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsAAAARecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsAAAARecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsAAAARecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsCnameRecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsCnameRecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsCnameRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsHostRecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsHostRecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsHostRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsNaptrRecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsNaptrRecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsNaptrRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsResourceRecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsResourceRecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsResourceRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsSrvRecord.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsSrvRecord.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsSrvRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsStub.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsStub.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsStub.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/DnsThread.cxx" "rutil/CMakeFiles/rutil.dir/dns/DnsThread.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/DnsThread.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/ExternalDnsFactory.cxx" "rutil/CMakeFiles/rutil.dir/dns/ExternalDnsFactory.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/ExternalDnsFactory.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/QueryTypes.cxx" "rutil/CMakeFiles/rutil.dir/dns/QueryTypes.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/QueryTypes.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/RRCache.cxx" "rutil/CMakeFiles/rutil.dir/dns/RRCache.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/RRCache.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/RRList.cxx" "rutil/CMakeFiles/rutil.dir/dns/RRList.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/RRList.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/RROverlay.cxx" "rutil/CMakeFiles/rutil.dir/dns/RROverlay.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/RROverlay.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/dns/RRVip.cxx" "rutil/CMakeFiles/rutil.dir/dns/RRVip.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/dns/RRVip.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/hep/HepAgent.cxx" "rutil/CMakeFiles/rutil.dir/hep/HepAgent.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/hep/HepAgent.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/hep/ResipHep.cxx" "rutil/CMakeFiles/rutil.dir/hep/ResipHep.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/hep/ResipHep.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/resipfaststreams.cxx" "rutil/CMakeFiles/rutil.dir/resipfaststreams.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/resipfaststreams.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ssl/OpenSSLDeleter.cxx" "rutil/CMakeFiles/rutil.dir/ssl/OpenSSLDeleter.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ssl/OpenSSLDeleter.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ssl/OpenSSLInit.cxx" "rutil/CMakeFiles/rutil.dir/ssl/OpenSSLInit.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ssl/OpenSSLInit.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/ssl/SHA1Stream.cxx" "rutil/CMakeFiles/rutil.dir/ssl/SHA1Stream.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/ssl/SHA1Stream.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/stun/Stun.cxx" "rutil/CMakeFiles/rutil.dir/stun/Stun.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/stun/Stun.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/stun/Udp.cxx" "rutil/CMakeFiles/rutil.dir/stun/Udp.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/stun/Udp.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/rutil/vmd5.cxx" "rutil/CMakeFiles/rutil.dir/vmd5.cxx.o" "gcc" "rutil/CMakeFiles/rutil.dir/vmd5.cxx.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
