rutil/CMakeFiles/rutil.dir/NetNs.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/rutil/NetNs.cxx \
 /usr/include/stdc-predef.h
