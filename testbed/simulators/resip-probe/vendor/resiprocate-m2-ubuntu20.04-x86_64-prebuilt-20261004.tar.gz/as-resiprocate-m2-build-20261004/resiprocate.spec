Name: resiprocate
Version: 1.14.0
Release: 1%{?dist}
Summary: SIP and TURN stacks, with SIP proxy and TURN server implementations
License: VSL
Url: http://www.resiprocate.org
Source: https://www.resiprocate.org/files/pub/reSIProcate/releases/%name-%version.tar.gz
BuildRequires: gcc-c++
BuildRequires: cmake
%define build_return 0%{?fedora} >= 30 || 0%{?rhel} >= 8
%if %build_return
BuildRequires: asio-devel >= 1.12.0
%endif
BuildRequires: boost-devel
BuildRequires: cajun-jsonapi-devel
BuildRequires: c-ares-devel
BuildRequires: cppunit-devel
BuildRequires: fmt-devel
BuildRequires: gperf
BuildRequires: gstreamer1-devel
BuildRequires: gstreamer1-plugins-base-devel
BuildRequires: gstreamer1-plugins-bad-free-devel
BuildRequires: gstreamermm-devel
%if 0%{?fedora} >= 34 || 0%{?rhel} >= 8
BuildRequires: libdb-cxx-devel
%endif
%define use_systemd 0%{?fedora} >= 17 || 0%{?rhel} >= 7
%if %use_systemd
BuildRequires: systemd
%endif
BuildRequires: libdb-devel
BuildRequires: openssl-devel >= 1.1.0
%define use_mariadb 0%{?fedora} >= 30 || 0%{?rhel} >= 8
%if %use_mariadb
BuildRequires: mariadb-connector-c-devel
%else
BuildRequires: mysql-devel
%endif
BuildRequires: pcre-devel
BuildRequires: perl-interpreter
BuildRequires: popt-devel
BuildRequires: libpq-devel
BuildRequires: python3-devel
BuildRequires: python3-pycxx-devel
%define use_radcli 0%{?fedora} == 0 || 0%{?fedora} >= 23 || 0%{?rhel} >= 6
%if %use_radcli
BuildRequires: radcli-devel
%else
%define use_freeradius_client 0%{?fedora} == 0 || 0%{?fedora} >= 21 || 0%{?rhel} >= 7
%if %use_freeradius_client
BuildRequires: freeradius-client-devel
%else
BuildRequires: radiusclient-ng-devel
%endif
%endif
BuildRequires: xerces-c-devel
BuildRequires: net-snmp-devel
BuildRequires: qpid-proton-cpp-devel
BuildRequires: soci-devel
BuildRequires: soci-mysql-devel
BuildRequires: soci-postgresql-devel
BuildRequires: sox
# vim-common contains the xxd utility
BuildRequires: vim-common
BuildRequires: websocketpp-devel
Requires: openssl >= 1.1.0
%if %use_systemd
Requires(post): systemd
Requires(preun): systemd
Requires(postun): systemd
%else
Requires: chkconfig
Requires(preun): initscripts
%endif
Obsoletes: resiprocate-b2bua < 1.9.0

%description
The reSIProcate components, particularly the SIP stack, are in use in both
commercial and open-source products. The project is dedicated to maintaining
a complete, correct, and commercially usable implementation of SIP and a few
related protocols.

%package libs
Summary: Shared libraries http://www.resiprocate.org

%description libs
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.
This package provides the core libraries: librutil (utilities),
libresip (SIP stack/RFC compliant message parsing) and
libdum (SIP Dialog Usage Manager, a state machine for SIP dialogs).

%package devel
Summary: reSIProcate development files
Requires: %{name}-libs%{?_isa} = %{version}-%{release}

%description devel
Resiprocate SIP Stack development files.

%package repro
Summary: SIP proxy
Requires(pre): shadow-utils

%description repro
repro is the SIP proxy developed as part of the reSIProcate project.
It provides a high-quality, low maintenance solution for serving
small and large IP telephony installations.
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.

%if %build_return
%package turn-server
Summary: ICE/STUN/TURN server
Requires(pre): shadow-utils

%description turn-server
reTurn is the TURN server developed as part of the reSIProcate project.
TURN (RFC 5766) provides a standardised solution for VoIP applications
to find the most efficient way to route media streams when NAT and
firewall devices may be present.
reTurn provides a high-quality, low maintenance solution for serving
small and large IP telephony installations.  It has been used successfully
with a variety of SIP and Jabber applications, including Lumicall,
Jitsi, Empathy and Psi.
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.
%endif

%if %build_return
%package turn-server-psql
Summary: ICE/STUN/TURN server PostgreSQL users script
Requires: python3-psycopg2

%description turn-server-psql
reTurn is the TURN server developed as part of the reSIProcate project.
This packages provides a Python script to synchronize the reTurn
users.txt file from a PostgreSQL table.
%endif

%package sipdialer
Summary: Click-to-call utility

%description sipdialer
sipdialer is a click-to-call application that uses the SIP REFER
method to force a SIP phone (for example, the phone on your desk)
to dial another number.  It can be registered in GConf to handle
clicks on sip:, sips: and tel: URIs in other applications and the
web browser.
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.

%package clicktocall
Summary: Click-to-call server process

%description clicktocall
Provides a simple SIP click-to-call service.
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.

%package registration-agent
Summary: SIP registration agent process

%description registration-agent
An agent process to submit REGISTER requests with a synthetic Contact
header for routing calls back to a SIP proxy or some other endpoint that
can't submit a REGISTER request itself
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.

%package mibs
Summary: MIBs for SNMP users

%description mibs
MIB files describing the properties exposed by the SNMP agents
in reSIProcate-based processes.  These are typically installed on the
monitoring host that polls the reSIProcate services.

%package reconserver
Summary: Conferencing and SBC process

%description reconserver
A process for hosting multi-user conferences or acting as an SBC or B2BUA,
bridging calls and media streams between different endpoints.
reSIProcate is a framework that aims to fully implement the SIP protocol
in first class C++.  It is intended for use in other applications,
such as the repro SIP proxy.

%prep
%setup -q

%build
PYCONFIG=/usr/bin/python3-config
if [ ! -x $PYCONFIG ] ; then echo "python*-config not found" ; exit 1 ; fi
PYVERSION=`python3 -c "import sys; print('%d.%d' % (sys.version_info[0], sys.version_info[1]))"`
%if %use_radcli
RADIUS_CFG=--with-radcli
%else
%if %use_freeradius_client
RADIUS_CFG=--with-freeradius
%else
RADIUS_CFG=--with-radius
%endif
%endif
%if %build_return
RETURN_CFG=--with-return
%endif
%define use_srtp1 0%{?rhel} == 8
%if %use_srtp1
SRTP1=-DUSE_SRTP1=ON
%else
SRTP1=-DUSE_SRTP1=OFF
%endif
export LDFLAGS="${LDFLAGS} -L%{_libdir}/mysql -L%{_libdir}/libdb4"
CPPFLAGS="`net-snmp-config --base-cflags`" CXXFLAGS="%{optflags} -I%{_includedir}/libdb4 -D__STDC_LIMIT_MACROS -D__STDC_CONSTANT_MACROS -D__STDC_FORMAT_MACROS -I/usr/include/soci"
# FIXME - enable FMT
# FIXME - enable GStreamer - requires gst-webrtc header tweak
%cmake \
    -DENABLE_LOG_REPOSITORY_DETAILS=OFF \
    -DRUN_GPERF=ON \
    -DCMAKE_BUILD_TYPE=Debug \
    -DCMAKE_CXX_FLAGS="${CPPFLAGS} ${CXXFLAGS}" \
    -DCMAKE_C_FLAGS="${CPPFLAGS} ${CFLAGS}" \
    -DWITH_C_ARES=ON \
    -DWITH_SSL=ON \
    -DUSE_POPT=ON \
    -DUSE_SIGCOMP=OFF \
    -DUSE_FMT=OFF \
    -DVERSIONED_SONAME=ON \
    -DENABLE_ANDROID=OFF \
    -DUSE_IPV6=ON \
    -DUSE_DTLS=ON \
    -DPEDANTIC_STACK=OFF \
    -DUSE_MYSQL=ON \
    -DUSE_SOCI_POSTGRESQL=ON \
    -DUSE_SOCI_MYSQL=ON \
    -DUSE_POSTGRESQL=ON \
    -DUSE_MAXMIND_GEOIP=OFF \
    -DRESIP_HAVE_RADCLI=ON \
    -DUSE_NETSNMP=ON \
    -DBUILD_REPRO=ON \
    -DBUILD_REPRO_DSO_PLUGINS=ON \
    -DBUILD_RETURN=ON \
    -DBUILD_REND=OFF \
    -DBUILD_TFM=OFF \
    -DBUILD_ICHAT_GW=OFF \
    -DBUILD_TELEPATHY_CM=OFF \
    -DBUILD_RECON=ON \
    ${SRTP1} \
    -DBUILD_RECONSERVER=ON \
    -DUSE_SIPXTAPI=OFF \
    -DUSE_KURENTO=ON \
    -DUSE_GSTREAMER=OFF \
    -DUSE_LIBWEBRTC=OFF \
    -DRECON_LOCAL_HW_TESTS=OFF \
    -DDEFAULT_BRIDGE_MAX_IN_OUTPUTS=20 \
    -DBUILD_P2P=OFF \
    -DBUILD_PYTHON=ON \
    -DBUILD_QPID_PROTON=ON \
    -DRESIP_ASSERT_SYSLOG=ON
%cmake_build

%install
%cmake_install
%if %use_systemd
install -p -D -m644 repro/pkg/common/repro.service %{buildroot}%{_unitdir}/repro.service
install -p -D -m644 apps/reConServer/pkg/common/reconserver.service %{buildroot}%{_unitdir}/reconserver.service
%if %build_return
install -p -D -m644 reTurn/pkg/common/resiprocate-turn-server.service %{buildroot}%{_unitdir}/resiprocate-turn-server.service
%endif
%else
install -p -D -m755 repro/pkg/fedora/repro.init %{buildroot}%{_initddir}/repro
install -p -D -m755 apps/reConServer/pkg/fedora/reconserver.init %{buildroot}%{_initddir}/reconserver
%if %build_return
install -p -D -m755 reTurn/pkg/fedora/resiprocate-turn-server.init %{buildroot}%{_initddir}/resiprocate-turn-server
%endif
%endif
install -m 0755 -d %{buildroot}%{_sysconfdir}/repro
install -p -D -m640 repro/repro.config %{buildroot}%{_sysconfdir}/repro/repro.config
install -p -D -m640 repro/users.txt %{buildroot}%{_sysconfdir}/repro/users.txt
sed -i \
 -e 's!^#CAFile = /etc/pki/tls/cert.pem$!CAFile = /etc/pki/tls/cert.pem!' \
 -e 's!^LoggingType = cout$!LoggingType = syslog!' \
 -e 's!^LogLevel = INFO$!LogLevel = DEBUG!' \
 -e 's!^LogFilename = repro.log$!LogFilename = %{_localstatedir}/log/repro/repro.log!' \
 -e 's!^LogFileMaxBytes = 5242880!LogFileMaxBytes = 0!' \
 -e 's!^TlsDHParamsFilename = dh2048.pem!TlsDHParamsFilename = %{_sysconfdir}/repro/dh2048.pem!' \
 -e 's!^HttpAdminUserFile = users.txt$!HttpAdminUserFile = %{_sysconfdir}/repro/users.txt!' \
 -e 's!^#PluginDirectory = /usr/lib/repro/plugins$!PluginDirectory = %{_libdir}/resiprocate/repro/plugins!' \
 -e 's!^#RunAsUser = repro$!RunAsUser = repro!' \
 -e 's!^#RunAsGroup = repro$!RunAsGroup = repro!' \
 -e 's!^Daemonize = false$!Daemonize = true!' \
 -e 's!^Database1Path = ./$!Database1Path = %{_sharedstatedir}/repro!' \
 -e 's!^ChallengeThirdPartiesCallingLocalDomains = true$!ChallengeThirdPartiesCallingLocalDomains = false!' \
            %{buildroot}%{_sysconfdir}/repro/repro.config
%if %build_return
install -p -D -m640 reTurn/reTurnServer.config %{buildroot}%{_sysconfdir}/reTurn/reTurnServer.config
install -p -D -m640 reTurn/users.txt %{buildroot}%{_sysconfdir}/reTurn/users.txt
sed -i -e 's/1234/6078a36f89704d83763c9e174b3e87a4/' %{buildroot}%{_sysconfdir}/reTurn/users.txt
sed -i \
 -e 's!^TlsTurnPort = 5349!TlsTurnPort = 0!' \
 -e 's!^LoggingType = file$!LoggingType = syslog!' \
 -e 's!^LogFilename = reTurnServer.log!LogFilename = %{_localstatedir}/log/reTurnServer/reTurnServer.log!' \
 -e 's!^LogFileMaxLines = 50000!LogFileMaxLines = 0!' \
 -e 's!^Daemonize = false!Daemonize = true!' \
 -e 's!^#RunAsUser = return!RunAsUser = return!' \
 -e 's!^#RunAsGroup = return!RunAsGroup = return!' \
 -e 's!^UserDatabaseFile = users.txt!UserDatabaseFile = %{_sysconfdir}/reTurn/users.txt!' \
 -e 's!^UserDatabaseHashedPasswords = false!UserDatabaseHashedPasswords = true!' \
 -e 's!^TlsTempDhFilename = dh2048.pem!TlsTempDhFilename = %{_sysconfdir}/reTurn/dh2048.pem!' \
            %{buildroot}%{_sysconfdir}/reTurn/reTurnServer.config
%endif
install -m 0755 -d %{buildroot}%{_sharedstatedir}/repro
rm -f %{buildroot}%{_libdir}/lib*.a
rm -f %{buildroot}%{_libdir}/lib*.la
rm -f %{buildroot}%{_libdir}/resiprocate/repro/plugins/lib*.a
rm -f %{buildroot}%{_libdir}/resiprocate/repro/plugins/lib*.la
install -m 0755 -d %{buildroot}/%{_docdir}/repro/examples/pyroute
install -p -D -m644 repro/plugins/pyroute/*.py %{buildroot}/%{_docdir}/repro/examples/pyroute
install -p -D -m644 repro/plugins/pyroute/README.txt %{buildroot}/%{_docdir}/repro/examples/pyroute
install -m 0755 -d %{buildroot}%{_sysconfdir}/reConServer
install -p -D -m640 apps/reConServer/reConServer.config %{buildroot}%{_sysconfdir}/reConServer/reConServer.config
sed -i \
 -e 's!^#CAFile = /etc/pki/tls/cert.pem$!CAFile = /etc/pki/tls/cert.pem!' \
 -e 's!^LoggingType = cout$!LoggingType = syslog!' \
 -e 's!^LogLevel = INFO$!LogLevel = DEBUG!' \
 -e 's!^LogFilename = reConServer.log$!LogFilename = %{_localstatedir}/log/reconserver/reconserver.log!' \
 -e 's!^LogFileMaxBytes = 5242880!LogFileMaxBytes = 0!' \
 -e 's!^TlsDHParamsFilename = dh2048.pem!TlsDHParamsFilename = %{_sysconfdir}/reConServer/dh2048.pem!' \
 -e 's!^#RunAsUser = recon$!RunAsUser = reconserver!' \
 -e 's!^#RunAsGroup = recon$!RunAsGroup = reconserver!' \
 -e 's!^Daemonize = false$!Daemonize = true!' \
            %{buildroot}%{_sysconfdir}/reConServer/reConServer.config

%pre repro
getent group repro >/dev/null || groupadd -r repro
getent passwd repro >/dev/null || \
    useradd -r -g repro -d %{_sharedstatedir}/repro -s /sbin/nologin \
    -c "repro SIP proxy" repro

%if %build_return
%pre turn-server
getent group return >/dev/null || groupadd -r return
getent passwd return >/dev/null || \
    useradd -r -g return -d / -s /sbin/nologin \
    -c "reTurn TURN server" return
%endif

%pre reconserver
getent group reconserver >/dev/null || groupadd -r reconserver
getent passwd reconserver >/dev/null || \
    useradd -r -g reconserver -d %{_sharedstatedir}/reconserver -s /sbin/nologin \
    -c "reconserver SIP Conversation Manager" reconserver

%ldconfig_scriptlets libs

%post repro
%{?ldconfig}
%if %use_systemd
%systemd_post repro.service
%else
if [ $1 -eq 1 ] ; then
    # Initial installation
    /sbin/chkconfig --add repro
fi
%endif
if [ ! -e %{_sysconfdir}/repro/dh2048.pem ] ;
then
  /usr/bin/openssl dhparam -outform PEM -out %{_sysconfdir}/repro/dh2048.pem 2048
  chown root:repro %{_sysconfdir}/repro/dh2048.pem
  chmod 0640 %{_sysconfdir}/repro/dh2048.pem
fi

%if %build_return
%post turn-server
%if %use_systemd
%systemd_post resiprocate-turn-server.service
%else
if [ $1 -eq 1 ] ; then
    # Initial installation
    /sbin/chkconfig --add resiprocate-turn-server
fi
%endif
if [ ! -e %{_sysconfdir}/reTurn/dh2048.pem ] ;
then
  /usr/bin/openssl dhparam -outform PEM -out %{_sysconfdir}/reTurn/dh2048.pem 2048
  chown root:return %{_sysconfdir}/reTurn/dh2048.pem
  chmod 0640 %{_sysconfdir}/reTurn/dh2048.pem
fi
%endif

%post reconserver
%{?ldconfig}
%if %use_systemd
%systemd_post reconserver.service
%else
if [ $1 -eq 1 ] ; then
    # Initial installation
    /sbin/chkconfig --add reconserver
fi
%endif
if [ ! -e %{_sysconfdir}/reConServer/dh2048.pem ] ;
then
  /usr/bin/openssl dhparam -outform PEM -out %{_sysconfdir}/reConServer/dh2048.pem 2048
  chown root:reconserver %{_sysconfdir}/reConServer/dh2048.pem
  chmod 0640 %{_sysconfdir}/reConServer/dh2048.pem
fi


%preun repro
%if %use_systemd
%systemd_preun repro.service
%else
if [ "$1" = 0 ]
then
   # Package removal, not upgrade
   /sbin/service repro stop
   /sbin/chkconfig --del repro
fi
%endif

%if %build_return
%preun turn-server
%if %use_systemd
%systemd_preun resiprocate-turn-server.service
%else
if [ "$1" = 0 ]
then
   # Package removal, not upgrade
   /sbin/service resiprocate-turn-server stop
   /sbin/chkconfig --del resiprocate-turn-server
fi
%endif
%endif

%preun reconserver
%if %use_systemd
%systemd_preun reconserver.service
%else
if [ "$1" = 0 ]
then
   # Package removal, not upgrade
   /sbin/service reconserver stop
   /sbin/chkconfig --del reconserver
fi
%endif

%postun repro
%{?ldconfig}
%if %use_systemd
%systemd_postun_with_restart repro.service
%else
if [ $1 -ge 1 ] ; then
    # Package upgrade, not uninstall
    /sbin/service repro try-restart
fi
%endif

%if %build_return
%postun turn-server
%if %use_systemd
%systemd_postun_with_restart resiprocate-turn-server.service
%else
if [ $1 -ge 1 ] ; then
    # Package upgrade, not uninstall
    /sbin/service resiprocate-turn-server try-restart
fi
%endif
%endif

%postun reconserver
%{?ldconfig}
%if %use_systemd
%systemd_postun_with_restart reconserver.service
%else
if [ $1 -ge 1 ] ; then
    # Package upgrade, not uninstall
    /sbin/service reconserver try-restart
fi
%endif

%files libs
%doc COPYING
%{_libdir}/libdum-*.so
%{_libdir}/libkurentoclient-*.so
%{_libdir}/librecon-*.so
%{_libdir}/libreflow-*.so
%{_libdir}/librepro-*.so
%{_libdir}/libresip-*.so
%{_libdir}/libresipmedia-*.so
%if %build_return
%{_libdir}/libreTurnClient-*.so
%{_libdir}/libreTurnCommon-*.so
%endif
%{_libdir}/librutil-*.so
%{_libdir}/libsipdial-*.so

%files devel
%dir %{_includedir}/clicktocall/
%dir %{_includedir}/media/
%dir %{_includedir}/media/kurento/
%if %build_return
%dir %{_includedir}/reTurn/
%dir %{_includedir}/reTurn/client/
%endif
%dir %{_includedir}/recon/
%dir %{_includedir}/recon/sdp/
%dir %{_includedir}/reflow/
%dir %{_includedir}/reflow/dtls_wrapper/
%dir %{_includedir}/repro/
%dir %{_includedir}/repro/monkeys/
%dir %{_includedir}/repro/stateAgents/
%dir %{_includedir}/resip/
%dir %{_includedir}/resip/dum/
%dir %{_includedir}/resip/dum/ssl/
%dir %{_includedir}/resip/stack/
%dir %{_includedir}/resip/stack/ssl/
%dir %{_includedir}/rutil/
%dir %{_includedir}/rutil/dns/
%dir %{_includedir}/rutil/rtcp/
%dir %{_includedir}/rutil/ssl/
%dir %{_includedir}/rutil/stun/
%dir %{_includedir}/rutil/wince/
%dir %{_includedir}/sipdial/
%{_includedir}/clicktocall/*.hxx
%{_includedir}/media/*.hxx
%{_includedir}/media/kurento/*.hxx
%if %build_return
%{_includedir}/reTurn/*.hxx
%{_includedir}/reTurn/client/*.hxx
%endif
%{_includedir}/recon/*.hxx
%{_includedir}/recon/*/*.hxx
%{_includedir}/reflow/*.hxx
%{_includedir}/reflow/dtls_wrapper/*.hxx
%{_includedir}/repro/*.hxx
%{_includedir}/repro/*/*.hxx
%{_includedir}/resip/dum/*.hxx
%{_includedir}/resip/dum/ssl/*.hxx
%{_includedir}/resip/stack/*.hxx
%{_includedir}/resip/stack/ssl/*.hxx
%{_includedir}/rutil/*.hxx
%{_includedir}/rutil/*.h
%{_includedir}/rutil/*/*.hxx
%{_includedir}/rutil/*/*.h
%{_includedir}/sipdial/*.hxx
%{_libdir}/libdum.so
%{_libdir}/libkurentoclient.so
%{_libdir}/librecon.so
%{_libdir}/libreflow.so
%{_libdir}/librepro.so
%{_libdir}/libresip.so
%{_libdir}/libresipmedia.so
%if %build_return
%{_libdir}/libreTurnClient.so
%{_libdir}/libreTurnCommon.so
%endif
%{_libdir}/librutil.so
%{_libdir}/libsipdial.so

%files repro
%attr(0750,repro,repro) %dir %{_sharedstatedir}/repro
%attr(0640,root,repro) %config(noreplace) %{_sysconfdir}/repro/repro.config
%attr(0640,root,repro) %config(noreplace) %{_sysconfdir}/repro/users.txt
%config(missingok) %ghost %{_sysconfdir}/repro/dh2048.pem
%if %use_systemd
%{_unitdir}/repro.service
%else
%{_initddir}/repro
%endif
%{_sbindir}/repro
%{_sbindir}/reprocmd
%{_sbindir}/queuetostream
%{_mandir}/man8/repro*.8*
%dir %{_libdir}/resiprocate/repro/plugins
%{_libdir}/resiprocate/repro/plugins/*.so
%{_docdir}/repro

%if %build_return
%files turn-server
%attr(0640,root,return) %config(noreplace) %{_sysconfdir}/reTurn/reTurnServer.config
%attr(0640,root,return) %config(noreplace) %{_sysconfdir}/reTurn/users.txt
%config(missingok) %ghost %{_sysconfdir}/reTurn/dh2048.pem
%dir %{_libdir}/resiprocate/reTurnServer
%if %use_systemd
%{_unitdir}/resiprocate-turn-server.service
%else
%{_initddir}/resiprocate-turn-server
%endif
%{_sbindir}/reTurnServer
%{_mandir}/man8/reTurnServer.8*
%endif

%if %build_return
%files turn-server-psql
%{_libdir}/resiprocate/reTurnServer/psql-user-extract
%endif

%files sipdialer
%{_bindir}/sipdialer
%{_mandir}/man1/sipdialer.1*

%files clicktocall
%{_sbindir}/clicktocall

%files registration-agent
%{_sbindir}/registrationAgent
%{_mandir}/man8/registrationAgent.8*

%files mibs
%{_datadir}/snmp/mibs/REG-AGENT-MIB.txt

%files reconserver
%attr(0640,root,reconserver) %config(noreplace) %{_sysconfdir}/reConServer/reConServer.config
%config(missingok) %ghost %{_sysconfdir}/reConServer/dh2048.pem
%if %use_systemd
%{_unitdir}/reconserver.service
%else
%{_initddir}/reconserver
%endif
%{_sbindir}/reConServer
%{_mandir}/man8/reConServer*.8*

%changelog
* Wed Jun 09 2021 Daniel Pocock <daniel@pocock.pro> - -1
- Produce multiple packages for stack/libs, daemons, sipdialer
- Initial build based on autotools

