
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialog.cxx" "resip/dum/CMakeFiles/dum.dir/AppDialog.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/AppDialog.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialogSet.cxx" "resip/dum/CMakeFiles/dum.dir/AppDialogSet.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/AppDialogSet.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialogSetFactory.cxx" "resip/dum/CMakeFiles/dum.dir/AppDialogSetFactory.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/AppDialogSetFactory.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseCreator.cxx" "resip/dum/CMakeFiles/dum.dir/BaseCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/BaseCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseSubscription.cxx" "resip/dum/CMakeFiles/dum.dir/BaseSubscription.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/BaseSubscription.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseUsage.cxx" "resip/dum/CMakeFiles/dum.dir/BaseUsage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/BaseUsage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/CertMessage.cxx" "resip/dum/CMakeFiles/dum.dir/CertMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/CertMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ChallengeInfo.cxx" "resip/dum/CMakeFiles/dum.dir/ChallengeInfo.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ChallengeInfo.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientAuthExtension.cxx" "resip/dum/CMakeFiles/dum.dir/ClientAuthExtension.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientAuthExtension.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientAuthManager.cxx" "resip/dum/CMakeFiles/dum.dir/ClientAuthManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientAuthManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientInviteSession.cxx" "resip/dum/CMakeFiles/dum.dir/ClientInviteSession.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientInviteSession.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientOutOfDialogReq.cxx" "resip/dum/CMakeFiles/dum.dir/ClientOutOfDialogReq.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientOutOfDialogReq.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientPagerMessage.cxx" "resip/dum/CMakeFiles/dum.dir/ClientPagerMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientPagerMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientPublication.cxx" "resip/dum/CMakeFiles/dum.dir/ClientPublication.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientPublication.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientRegistration.cxx" "resip/dum/CMakeFiles/dum.dir/ClientRegistration.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientRegistration.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientSubscription.cxx" "resip/dum/CMakeFiles/dum.dir/ClientSubscription.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ClientSubscription.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ContactInstanceRecord.cxx" "resip/dum/CMakeFiles/dum.dir/ContactInstanceRecord.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ContactInstanceRecord.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DefaultServerReferHandler.cxx" "resip/dum/CMakeFiles/dum.dir/DefaultServerReferHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DefaultServerReferHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DestroyUsage.cxx" "resip/dum/CMakeFiles/dum.dir/DestroyUsage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DestroyUsage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/Dialog.cxx" "resip/dum/CMakeFiles/dum.dir/Dialog.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/Dialog.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogEventInfo.cxx" "resip/dum/CMakeFiles/dum.dir/DialogEventInfo.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogEventInfo.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogEventStateManager.cxx" "resip/dum/CMakeFiles/dum.dir/DialogEventStateManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogEventStateManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogId.cxx" "resip/dum/CMakeFiles/dum.dir/DialogId.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogId.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogSet.cxx" "resip/dum/CMakeFiles/dum.dir/DialogSet.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogSet.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogSetId.cxx" "resip/dum/CMakeFiles/dum.dir/DialogSetId.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogSetId.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogUsage.cxx" "resip/dum/CMakeFiles/dum.dir/DialogUsage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogUsage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogUsageManager.cxx" "resip/dum/CMakeFiles/dum.dir/DialogUsageManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DialogUsageManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumDecrypted.cxx" "resip/dum/CMakeFiles/dum.dir/DumDecrypted.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumDecrypted.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeature.cxx" "resip/dum/CMakeFiles/dum.dir/DumFeature.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumFeature.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeatureChain.cxx" "resip/dum/CMakeFiles/dum.dir/DumFeatureChain.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumFeatureChain.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeatureMessage.cxx" "resip/dum/CMakeFiles/dum.dir/DumFeatureMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumFeatureMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumHelper.cxx" "resip/dum/CMakeFiles/dum.dir/DumHelper.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumHelper.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumProcessHandler.cxx" "resip/dum/CMakeFiles/dum.dir/DumProcessHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumProcessHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumThread.cxx" "resip/dum/CMakeFiles/dum.dir/DumThread.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumThread.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/DumTimeout.cxx" "resip/dum/CMakeFiles/dum.dir/DumTimeout.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/DumTimeout.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/EncryptionRequest.cxx" "resip/dum/CMakeFiles/dum.dir/EncryptionRequest.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/EncryptionRequest.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/Handle.cxx" "resip/dum/CMakeFiles/dum.dir/Handle.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/Handle.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/HandleException.cxx" "resip/dum/CMakeFiles/dum.dir/HandleException.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/HandleException.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/HandleManager.cxx" "resip/dum/CMakeFiles/dum.dir/HandleManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/HandleManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/Handled.cxx" "resip/dum/CMakeFiles/dum.dir/Handled.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/Handled.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/HttpGetMessage.cxx" "resip/dum/CMakeFiles/dum.dir/HttpGetMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/HttpGetMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/HttpProvider.cxx" "resip/dum/CMakeFiles/dum.dir/HttpProvider.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/HttpProvider.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/IdentityHandler.cxx" "resip/dum/CMakeFiles/dum.dir/IdentityHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/IdentityHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemoryRegistrationDatabase.cxx" "resip/dum/CMakeFiles/dum.dir/InMemoryRegistrationDatabase.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InMemoryRegistrationDatabase.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemorySyncPubDb.cxx" "resip/dum/CMakeFiles/dum.dir/InMemorySyncPubDb.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InMemorySyncPubDb.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemorySyncRegDb.cxx" "resip/dum/CMakeFiles/dum.dir/InMemorySyncRegDb.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InMemorySyncRegDb.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSession.cxx" "resip/dum/CMakeFiles/dum.dir/InviteSession.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InviteSession.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSessionCreator.cxx" "resip/dum/CMakeFiles/dum.dir/InviteSessionCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InviteSessionCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSessionHandler.cxx" "resip/dum/CMakeFiles/dum.dir/InviteSessionHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/InviteSessionHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/KeepAliveManager.cxx" "resip/dum/CMakeFiles/dum.dir/KeepAliveManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/KeepAliveManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/KeepAliveTimeout.cxx" "resip/dum/CMakeFiles/dum.dir/KeepAliveTimeout.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/KeepAliveTimeout.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/MasterProfile.cxx" "resip/dum/CMakeFiles/dum.dir/MasterProfile.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/MasterProfile.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/MergedRequestKey.cxx" "resip/dum/CMakeFiles/dum.dir/MergedRequestKey.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/MergedRequestKey.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/MergedRequestRemovalCommand.cxx" "resip/dum/CMakeFiles/dum.dir/MergedRequestRemovalCommand.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/MergedRequestRemovalCommand.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/NetworkAssociation.cxx" "resip/dum/CMakeFiles/dum.dir/NetworkAssociation.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/NetworkAssociation.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/NonDialogUsage.cxx" "resip/dum/CMakeFiles/dum.dir/NonDialogUsage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/NonDialogUsage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/OutOfDialogReqCreator.cxx" "resip/dum/CMakeFiles/dum.dir/OutOfDialogReqCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/OutOfDialogReqCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/OutgoingEvent.cxx" "resip/dum/CMakeFiles/dum.dir/OutgoingEvent.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/OutgoingEvent.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/PagerMessageCreator.cxx" "resip/dum/CMakeFiles/dum.dir/PagerMessageCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/PagerMessageCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/Profile.cxx" "resip/dum/CMakeFiles/dum.dir/Profile.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/Profile.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/PublicationCreator.cxx" "resip/dum/CMakeFiles/dum.dir/PublicationCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/PublicationCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/RADIUSServerAuthManager.cxx" "resip/dum/CMakeFiles/dum.dir/RADIUSServerAuthManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/RADIUSServerAuthManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/RedirectManager.cxx" "resip/dum/CMakeFiles/dum.dir/RedirectManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/RedirectManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/RegistrationCreator.cxx" "resip/dum/CMakeFiles/dum.dir/RegistrationCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/RegistrationCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/RegistrationHandler.cxx" "resip/dum/CMakeFiles/dum.dir/RegistrationHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/RegistrationHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerAuthManager.cxx" "resip/dum/CMakeFiles/dum.dir/ServerAuthManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerAuthManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerInviteSession.cxx" "resip/dum/CMakeFiles/dum.dir/ServerInviteSession.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerInviteSession.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerOutOfDialogReq.cxx" "resip/dum/CMakeFiles/dum.dir/ServerOutOfDialogReq.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerOutOfDialogReq.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerPagerMessage.cxx" "resip/dum/CMakeFiles/dum.dir/ServerPagerMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerPagerMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerPublication.cxx" "resip/dum/CMakeFiles/dum.dir/ServerPublication.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerPublication.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerRegistration.cxx" "resip/dum/CMakeFiles/dum.dir/ServerRegistration.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerRegistration.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerSubscription.cxx" "resip/dum/CMakeFiles/dum.dir/ServerSubscription.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ServerSubscription.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionCreator.cxx" "resip/dum/CMakeFiles/dum.dir/SubscriptionCreator.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/SubscriptionCreator.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionHandler.cxx" "resip/dum/CMakeFiles/dum.dir/SubscriptionHandler.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/SubscriptionHandler.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionState.cxx" "resip/dum/CMakeFiles/dum.dir/SubscriptionState.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/SubscriptionState.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/TargetCommand.cxx" "resip/dum/CMakeFiles/dum.dir/TargetCommand.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/TargetCommand.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/TlsPeerAuthManager.cxx" "resip/dum/CMakeFiles/dum.dir/TlsPeerAuthManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/TlsPeerAuthManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/TlsPeerIdentityInfoMessage.cxx" "resip/dum/CMakeFiles/dum.dir/TlsPeerIdentityInfoMessage.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/TlsPeerIdentityInfoMessage.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/UserAuthInfo.cxx" "resip/dum/CMakeFiles/dum.dir/UserAuthInfo.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/UserAuthInfo.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/UserProfile.cxx" "resip/dum/CMakeFiles/dum.dir/UserProfile.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/UserProfile.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/WsCookieAuthManager.cxx" "resip/dum/CMakeFiles/dum.dir/WsCookieAuthManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/WsCookieAuthManager.cxx.o.d"
  "/tmp/as-resiprocate-m2-20261004/resip/dum/ssl/EncryptionManager.cxx" "resip/dum/CMakeFiles/dum.dir/ssl/EncryptionManager.cxx.o" "gcc" "resip/dum/CMakeFiles/dum.dir/ssl/EncryptionManager.cxx.o.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
