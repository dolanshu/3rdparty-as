resip/dum/CMakeFiles/dum.dir/Handle.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/resip/dum/Handle.cxx \
 /usr/include/stdc-predef.h
