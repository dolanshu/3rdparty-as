# Install script for directory: /tmp/as-resiprocate-m2-20261004/resip/dum

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/tmp/as-resiprocate-m2-install-20261004")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE FILE FILES "/tmp/as-resiprocate-m2-build-20261004/resip/dum/libdum.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/tmp/as-resiprocate-m2-build-20261004/resip/dum/libdum-1.14.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so"
         OLD_RPATH "/tmp/as-resiprocate-m2-build-20261004/resip/stack:/tmp/as-resiprocate-m2-build-20261004/rutil:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libdum-1.14.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/tmp/as-resiprocate-m2-build-20261004/resip/dum/CMakeFiles/dum.dir/install-cxx-module-bmi-Release.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialog.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialogSetFactory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/AppDialogSet.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseSubscription.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/BaseUsage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/CertMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ChallengeInfo.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientAuthExtension.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientAuthManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientInviteSession.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientOutOfDialogReq.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientPagerMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientPublication.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientRegistration.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientSubscriptionFunctor.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ClientSubscription.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ContactInstanceRecord.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DefaultServerReferHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DestroyUsage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogEventHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogEventInfo.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogEventStateManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Dialog.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogId.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogSetHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogSet.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogSetId.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogUsage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DialogUsageManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumCommand.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumDecrypted.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumException.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeatureChain.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeature.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumFeatureMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumHelper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumProcessHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumShutdownHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/DumTimeout.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/EncryptionRequest.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/EventDispatcher.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ExternalMessageBase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ExternalMessageHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ExternalTimer.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Handled.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/HandleException.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Handle.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/HandleManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Handles.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/HttpGetMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/HttpProvider.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/IdentityHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemoryRegistrationDatabase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemorySyncPubDb.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InMemorySyncRegDb.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteDialogs.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSessionCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSessionHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/InviteSession.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/KeepAliveManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/KeepAliveTimeout.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/MasterProfile.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/MergedRequestKey.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/MergedRequestRemovalCommand.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/NetworkAssociation.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/NonDialogUsage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/OutgoingEvent.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/OutOfDialogHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/OutOfDialogReqCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/PagerMessageCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/PagerMessageHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Postable.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/Profile.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/PublicationCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/PublicationHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/PublicationPersistenceManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RADIUSServerAuthManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RedirectHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RedirectManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RefCountedDestroyer.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RegistrationCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RegistrationHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RegistrationPersistenceManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RemoteCertStore.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/RequestValidationHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerAuthManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerInviteSession.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerOutOfDialogReq.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerPagerMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerPublication.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerRegistration.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerSubscriptionFunctor.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ServerSubscription.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/ssl/EncryptionManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionCreator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionPersistenceManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/SubscriptionState.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/TargetCommand.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/TlsPeerAuthManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/TlsPeerIdentityInfoMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/WsCookieAuthManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/UsageUseException.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/UserAuthInfo.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/dum" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/dum/UserProfile.hxx")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/tmp/as-resiprocate-m2-build-20261004/resip/dum/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
