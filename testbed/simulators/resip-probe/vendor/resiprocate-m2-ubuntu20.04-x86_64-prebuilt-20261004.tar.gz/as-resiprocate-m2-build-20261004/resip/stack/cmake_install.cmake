# Install script for directory: /tmp/as-resiprocate-m2-20261004/resip/stack

# Set the install prefix
if(NOT DEFINED CMAKE_INSTALL_PREFIX)
  set(CMAKE_INSTALL_PREFIX "/tmp/as-resiprocate-m2-install-20261004")
endif()
string(REGEX REPLACE "/$" "" CMAKE_INSTALL_PREFIX "${CMAKE_INSTALL_PREFIX}")

# Set the install configuration name.
if(NOT DEFINED CMAKE_INSTALL_CONFIG_NAME)
  if(BUILD_TYPE)
    string(REGEX REPLACE "^[^A-Za-z0-9_]+" ""
           CMAKE_INSTALL_CONFIG_NAME "${BUILD_TYPE}")
  else()
    set(CMAKE_INSTALL_CONFIG_NAME "Release")
  endif()
  message(STATUS "Install configuration: \"${CMAKE_INSTALL_CONFIG_NAME}\"")
endif()

# Set the component getting installed.
if(NOT CMAKE_INSTALL_COMPONENT)
  if(COMPONENT)
    message(STATUS "Install component: \"${COMPONENT}\"")
    set(CMAKE_INSTALL_COMPONENT "${COMPONENT}")
  else()
    set(CMAKE_INSTALL_COMPONENT)
  endif()
endif()

# Install shared libraries without execute permission?
if(NOT DEFINED CMAKE_INSTALL_SO_NO_EXE)
  set(CMAKE_INSTALL_SO_NO_EXE "1")
endif()

# Is this installation the result of a crosscompile?
if(NOT DEFINED CMAKE_CROSSCOMPILING)
  set(CMAKE_CROSSCOMPILING "FALSE")
endif()

# Set path to fallback-tool for dependency-resolution.
if(NOT DEFINED CMAKE_OBJDUMP)
  set(CMAKE_OBJDUMP "/usr/bin/objdump")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE FILE FILES "/tmp/as-resiprocate-m2-build-20261004/resip/stack/libresip.so")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so")
    file(RPATH_CHECK
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so"
         RPATH "")
  endif()
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/lib" TYPE SHARED_LIBRARY FILES "/tmp/as-resiprocate-m2-build-20261004/resip/stack/libresip-1.14.so")
  if(EXISTS "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so" AND
     NOT IS_SYMLINK "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so")
    file(RPATH_CHANGE
         FILE "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so"
         OLD_RPATH "/tmp/as-resiprocate-m2-build-20261004/rutil:"
         NEW_RPATH "")
    if(CMAKE_INSTALL_DO_STRIP)
      execute_process(COMMAND "/usr/bin/strip" "$ENV{DESTDIR}${CMAKE_INSTALL_PREFIX}/lib/libresip-1.14.so")
    endif()
  endif()
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  include("/tmp/as-resiprocate-m2-build-20261004/resip/stack/CMakeFiles/resip.dir/install-cxx-module-bmi-Release.cmake" OPTIONAL)
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/AbandonServerTransaction.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/AddTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Aor.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ApiCheck.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ApiCheckList.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ApplicationMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ApplicationSip.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Auth.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/BasicDomainMatcher.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/BasicNonceHelper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/BranchParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/CallId.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Cookie.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/CancelableTimerQueue.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/CancelClientInviteTransaction.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Compression.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ConnectionBase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Connection.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ConnectionManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ConnectionTerminated.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ContentsFactoryBase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ContentsFactory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Contents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/CpimContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/CSeqCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DataParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DateCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DeprecatedDialog.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DialogInfoContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Dispatcher.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DnsInterface.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DnsResult.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DnsResultMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DomainMatcher.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DtlsMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/DtmfPayloadContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Embedded.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/EnableFlowTimer.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/EventStackThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExistsOrDataParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExistsParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExpiresCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExtendedDomainMatcher.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExtensionHeader.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExtensionParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ExternalBodyContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/FloatParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/GenericContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/GenericPidfContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/GenericUri.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/HEPSipMessageLoggingHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/HeaderFieldValue.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/HeaderFieldValueList.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/HeaderHash.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Headers.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/HeaderTypes.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Helper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/IdentityCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/IntegerCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/IntegerParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/InternalTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/InteropHelper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/InterruptableStackThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/InvalidContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/InvokeAfterSocketCreationFunc.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/KeepAliveMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/KeepAlivePong.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/LazyParser.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MediaControlContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MarkListener.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MessageDecorator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MessageFilterRule.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Message.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MessageWaitingContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MethodHash.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MethodTypes.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Mime.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MsgHeaderScanner.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MultipartAlternativeContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MultipartMixedContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MultipartRelatedContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/MultipartSignedContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/NameAddr.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/NonceHelper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/OctetContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParameterHash.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Parameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParameterTypeEnums.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParameterTypes.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParserCategories.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParserCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParserContainerBase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ParserContainer.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Pkcs7Contents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Pkcs8Contents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/PlainContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/PollStatistics.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/PrivacyCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/QuotedDataParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/QValue.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/QValueParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/RAckCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ReceivedParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/RemoveTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/RequestLine.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Rlmi.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/RportParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SdpContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SecurityAttributes.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SecurityTypes.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SendData.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SERNonceHelper.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ShutdownMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SipConfigParse.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SipFrag.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SipMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/SipStack.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/DtlsTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/MacSecurity.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/Security.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/TlsBaseTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/TlsConnection.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/TlsTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/WinSecurity.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/WssTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack/ssl" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ssl/WssConnection.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StackThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StartLine.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StatelessHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StatisticsHandler.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StatisticsManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StatisticsMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StatusLine.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/StringCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Symbols.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TcpBaseTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TcpConnection.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TcpConnectState.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TcpTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TerminateFlow.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TimeAccumulate.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TimerMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TimerQueue.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Token.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TokenOrQuotedStringCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionController.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionControllerThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionMap.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransportSelectorThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionState.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionTerminated.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionUser.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransactionUserMessage.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransportFailure.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Transport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransportSelector.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TransportThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TrickleIceContents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TuIM.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Tuple.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TupleMarkManager.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/TuSelector.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UdpTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UInt32Category.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UInt32Parameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UnknownHeaderType.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UnknownParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UnknownParameterType.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Uri.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/UriParameter.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ValueFifo.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Via.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WarningCategory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/Worker.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WorkerThread.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsBaseTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsDecorator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsFrameExtractor.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsTransport.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsConnection.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsConnectionBase.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsConnectionValidator.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsCookieContext.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/WsCookieContextFactory.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/X509Contents.hxx")
endif()

if(CMAKE_INSTALL_COMPONENT STREQUAL "Unspecified" OR NOT CMAKE_INSTALL_COMPONENT)
  file(INSTALL DESTINATION "${CMAKE_INSTALL_PREFIX}/include/resip/stack" TYPE FILE FILES "/tmp/as-resiprocate-m2-20261004/resip/stack/ZeroOutStatistics.hxx")
endif()

string(REPLACE ";" "\n" CMAKE_INSTALL_MANIFEST_CONTENT
       "${CMAKE_INSTALL_MANIFEST_FILES}")
if(CMAKE_INSTALL_LOCAL_ONLY)
  file(WRITE "/tmp/as-resiprocate-m2-build-20261004/resip/stack/install_local_manifest.txt"
     "${CMAKE_INSTALL_MANIFEST_CONTENT}")
endif()
