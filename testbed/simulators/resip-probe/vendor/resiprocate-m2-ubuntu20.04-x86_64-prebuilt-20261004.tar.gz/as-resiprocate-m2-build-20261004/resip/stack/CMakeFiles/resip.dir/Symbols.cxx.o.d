resip/stack/CMakeFiles/resip.dir/Symbols.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/resip/stack/Symbols.cxx \
 /usr/include/stdc-predef.h \
 /tmp/as-resiprocate-m2-build-20261004/config.h \
 /tmp/as-resiprocate-m2-20261004/resip/stack/Symbols.hxx
