# Empty dependencies file for resip.
# This may be replaced when dependencies are built.
