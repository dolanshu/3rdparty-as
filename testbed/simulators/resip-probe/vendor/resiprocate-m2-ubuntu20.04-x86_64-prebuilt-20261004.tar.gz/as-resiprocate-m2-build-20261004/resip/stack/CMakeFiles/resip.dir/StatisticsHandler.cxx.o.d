resip/stack/CMakeFiles/resip.dir/StatisticsHandler.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/resip/stack/StatisticsHandler.cxx \
 /usr/include/stdc-predef.h \
 /tmp/as-resiprocate-m2-build-20261004/config.h \
 /tmp/as-resiprocate-m2-20261004/resip/stack/StatisticsHandler.hxx
