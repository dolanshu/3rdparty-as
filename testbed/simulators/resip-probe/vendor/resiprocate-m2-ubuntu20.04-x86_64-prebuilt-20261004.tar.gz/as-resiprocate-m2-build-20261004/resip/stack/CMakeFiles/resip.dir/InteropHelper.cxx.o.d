resip/stack/CMakeFiles/resip.dir/InteropHelper.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/resip/stack/InteropHelper.cxx \
 /usr/include/stdc-predef.h \
 /tmp/as-resiprocate-m2-20261004/resip/stack/InteropHelper.hxx
