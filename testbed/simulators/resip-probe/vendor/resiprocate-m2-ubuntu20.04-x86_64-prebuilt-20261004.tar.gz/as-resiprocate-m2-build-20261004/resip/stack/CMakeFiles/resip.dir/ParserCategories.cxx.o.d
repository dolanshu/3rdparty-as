resip/stack/CMakeFiles/resip.dir/ParserCategories.cxx.o: \
 /tmp/as-resiprocate-m2-20261004/resip/stack/ParserCategories.cxx \
 /usr/include/stdc-predef.h \
 /tmp/as-resiprocate-m2-build-20261004/config.h
