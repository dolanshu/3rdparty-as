file(REMOVE_RECURSE
  "CMakeFiles/sipdialer.dir/sipdialer.cpp.o"
  "CMakeFiles/sipdialer.dir/sipdialer.cpp.o.d"
  "sipdialer"
  "sipdialer.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/sipdialer.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
