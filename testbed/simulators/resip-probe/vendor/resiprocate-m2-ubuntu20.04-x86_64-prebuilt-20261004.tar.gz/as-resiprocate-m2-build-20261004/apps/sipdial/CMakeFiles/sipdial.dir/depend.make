# Empty dependencies file for sipdial.
# This may be replaced when dependencies are built.
