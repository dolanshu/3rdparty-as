# Empty dependencies file for sipdialer.
# This may be replaced when dependencies are built.
