file(REMOVE_RECURSE
  "CMakeFiles/sipdial.dir/DialInstance.cpp.o"
  "CMakeFiles/sipdial.dir/DialInstance.cpp.o.d"
  "CMakeFiles/sipdial.dir/DialerConfiguration.cpp.o"
  "CMakeFiles/sipdial.dir/DialerConfiguration.cpp.o.d"
  "CMakeFiles/sipdial.dir/MyInviteSessionHandler.cpp.o"
  "CMakeFiles/sipdial.dir/MyInviteSessionHandler.cpp.o.d"
  "libsipdial-1.14.pdb"
  "libsipdial-1.14.so"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/sipdial.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
