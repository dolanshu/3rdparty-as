/*
 More information can be obtained from
 http://www.cmake.org/Wiki/CMake:How_To_Write_Platform_Checks
*/

#define GPERF_SIZE_TYPE size_t
#define HAVE_EPOLL 1
/* #undef USE_MYSQL */
/* #undef USE_POSTGRESQL */
/* #undef USE_MAXMIND_GEOIP */
#define HAVE_CLOCK_GETTIME_MONOTONIC 1
#define DEFAULT_BRIDGE_MAX_IN_OUTPUTS 20
/* #undef SIPX_NO_RECORD */

#define ENABLE_LOG_REPOSITORY_DETAILS
#define RESIPROCATE_GIT_ID "632e215c2ca9aee5416bfe1808851ea6fa380044"
#define RESIPROCATE_BRANCH_NAME "HEAD"
/* #undef USE_FQDN_FOR_JSON_CEE_HOSTNAME */
/* #undef RESIP_BIG_ENDIAN */
/* #undef REPRO_BUILD_REV */
/* #undef REPRO_BUILD_HOST */
/* #undef DB_HEADER */
#define RESIP_SIP_MSG_MAX_BYTES 10485760
/* #undef USE_SIGCOMP */
#define RESIP_HAVE_STRING_VIEW 0

// TIME_WITH_SYS_TIME
// STDC_HEADERS
// more ...
