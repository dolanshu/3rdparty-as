# Empty dependencies file for resip_probe.
# This may be replaced when dependencies are built.
